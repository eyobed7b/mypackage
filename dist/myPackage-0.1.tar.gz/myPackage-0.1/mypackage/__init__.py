
from . import myModule